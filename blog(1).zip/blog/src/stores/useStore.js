import { defineStore } from 'pinia'

export const useStore = defineStore('STORE',{
    state:() =>({
        currentPageId:0
    }),
    getters:{

    },
    actions:{

    }
})