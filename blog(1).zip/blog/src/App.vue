<template>
    <div id="app">
      <Layout/>
    </div>
</template>

<script setup>
import Layout from '../src/layout/index.vue'

</script>

<style>
*{
  padding:0;
  margin:0;
  box-sizing: border-box;
}
li{
  list-style: none;
}
html,
body,#app{
  margin:0;
  padding:0;
  width: 100%;
}
</style>
