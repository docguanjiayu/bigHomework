<template>
        <!-- 头部信息 -->
        <div class="top">
            <div class="title">前端博客网</div>
            <div class="desc">关注Web前端开发，坚持分享实践教程的个人博客。</div>
            <div class="date">{{ moment(nowDate).format('YYYY年MM月DD日 dddd') }}</div>
        </div>
        <!-- 导航栏 -->
        <div class="nav">
            <ul>
                <li v-for="item in menuList" :key="item.id" 
                :class="{'activeLi' : currentId == item.id}"
                @click="toPage(item)"
                >{{ item.content }}</li>
            </ul>
            <div class="user" v-if="User.isLogin">
                <el-tooltip
                    class="box-item"
                    effect="dark"
                    content="用户主页"
                    placement="bottom">
                    <li v-for="item in center" :key="item.id" :class="{'activeLi' : currentId == item.id}" @click="toPage(item)">欢迎您 <span @click="toUserCenter">{{ User.userinfo.nickname }}</span></li>
                </el-tooltip>
                
                <el-tooltip
                    class="box-item"
                    effect="dark"
                    content="退出登录"
                    placement="bottom">
                    <div @click="exit">
                        <svg t="1673789199312" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="3494" width="22" height="22"><path d="M909.7728 517.376L746.3424 369.664a33.9456 33.9456 0 0 0-45.7728 0 26.7264 26.7264 0 0 0 0 41.3696L808.448 508.5184H494.592c-19.5584 0-32.6656 11.8272-32.6656 29.5424 0 17.7664 13.1072 29.5424 32.7168 29.5424H808.448L700.5696 665.1392a26.7264 26.7264 0 0 0 0 41.3696 31.1808 31.1808 0 0 0 22.8864 8.8576 31.232 31.232 0 0 0 22.8864-8.8576l163.4304-150.6816s0-2.9696 3.2768-2.9696a22.784 22.784 0 0 0-3.2768-35.4816z" p-id="3495" fill="#e8e8e8"></path><path d="M102.4 827.1872C102.4 880.6912 145.664 921.6 202.24 921.6h566.016c56.576 0 99.84-40.9088 99.84-94.4128v-62.976c0-18.8416-13.312-31.4368-33.28-31.4368s-33.28 12.5952-33.28 31.488v62.976c0 18.8416-13.312 31.4368-33.28 31.4368H202.24c-19.968 0-33.28-12.5952-33.28-31.488V197.8368c0-18.8928 13.312-31.488 33.28-31.488h565.9648c19.968 0 33.28 12.5952 33.28 31.488v62.9248c0 18.8928 13.312 31.488 33.28 31.488s33.28-12.5952 33.28-31.488v-62.976C868.096 144.384 824.832 103.424 768.256 103.424H202.24C145.664 103.424 102.4 144.3328 102.4 197.8368" p-id="3496" fill="#e8e8e8"></path></svg>
                    </div>
                </el-tooltip>
            </div>
            <ul v-else>
                <li v-for="item in login" :key="item.id"
                :class="{'activeLi' : currentId == item.id}"
                @click="toPage(item)">{{ item.content }}</li>
            </ul>
        </div>
</template>

<script setup>
import { ref, reactive } from 'vue'
import moment from 'moment'
import { useUser } from '@/stores/useLogin'
import { useRouter } from 'vue-router'
// import {useStore} from '../stores/useStore.js'

//路由器
const router = useRouter()

const currentId = ref(0)

// const store = useStore()
const User = useUser()

//当前日期
const nowDate = ref(new Date())

//菜单列表
const menuList = reactive([
    {
        id:0,
        content:'首页',
        path:'/'
    },
    {
        id:1,
        content:'发表',
        path:'/myCreate'
    },
    {
        id:2,
        content:'报告',
        path:'/about'
    }
])

//登陆注册
const login = reactive([
    {
        id:3,
        content:'登录',
        path:'/login'
    },
    {
        id:4,
        content:'注册',
        path:'/register'
    }
])

//个人中心
const center = reactive([
    {
        id:5,
        content:'',
        path:'/userCenter'
    }
])

//跳转页面
const toPage = (item) => {
    currentId.value = item.id
    router.push({path:item.path})
}

//退出登录
const exit = () => {
    User.exitLogin()
}

</script>

<style scoped lang='less'>
    .top{
        width: 100%;
        text-align: center;
        padding:10px;
        background-color: #fff;
        font-size: 14px;
        color: #444;

        .title{
            font-size: 25px;
        }

        .date{
            color:#666;
        }

        div{
            margin-top: 5px;
        }
    }
    .nav{

        padding:10px;
        background-color: #444;
        color:#cdcdcd;
        display: flex;
        justify-content: space-between;
        ul{
            display: flex;
            li{
                padding:0 10px;
                cursor: pointer;
                transition: 0.4s;
            }
            li:hover{
                color:#fff;
            }
            .activeLi{
                color:#fff;
                font-weight: 400;
            }
        }

        .user{
            display: flex;
            li,div{
                cursor: pointer;
                padding:0 10px;
                span{
                    color: #e8e8e8;
                }
            }
        }
    }
    
</style>