export const hot = [
    {
        id:1,
        title:'JS实现页面停留指定时间再跳转',
        author:'大卫学前端',
        tag:'JavaScript',
        desc:'页面停留指定时间再跳转',
        readcount:5750,
        createTime:new Date('2021/8/15 17:52:56'),
        content:
        `
            函数加timeout定时器实现。

            <script type="text/javascript">
              function jumurl(){
                  window.location.href = 'http://www.baidu.com/';
              }
              setTimeout(jumurl,3000);
            </script>
        `
    },
    {
        id:2,
        title:'PostgreSql数据库-创建用户、数据库、schema',
        author:'yofe',
        tag:'PostgreSQL',
        desc:'PostgreSql数据库-创建用户、数据库、schema',
        readcount:1225,
        createTime:new Date('2023/1/10 22:23:40'),
        content:
        `
            PostgreSql数据库-创建用户、数据库、schema


            -- postgres用户执行
            create user tzq with password '1';
            create database tzqdb owner tzq;
            grant all privileges on database tzqdb to tzq;
            
            -- tzq用户执行
            create schema tzq authorization tzq;
        `
    },
    {
        id:3,
        title:'html跑马灯/走马灯效果',
        author:'小东',
        tag:'CSS',
        desc:'实现跑马灯的方法很多，其中最简单的是采用一句Html代码来实现',
        readcount:4134,
        createTime:new Date('2021/5/10 21:23:40'),
        content:
        `
            html跑马灯/走马灯效果

            实现跑马灯的方法很多，其中最简单的是采用一句Html代码来实现，我们在需要出现跑马灯效果的地方插入“滚动的文字”语句。
            
            实现的方法就是在IE的标签上稍微多加了几个参数产生了更加丰富的变化。设置behavior=alternate表示双向移动，direction= left表示运动方向向左。marquee的宽度可以使用绝对象素值，例如width=200等这个值限定了跑马灯滚动的范围。需要说明的是该效果在 Netscape下是看不到的。弹来弹去跑马灯!
            
            <marquee width=400 behavior=alternate direction=left align=middle>弹来弹去跑马灯!</marquee>
            
            只要在<marquee>标签后面加上“scrollamount=15”即可,修改=后边的数字参数即可限制文字移动的速度。
            
            如果你想给跑马灯的文字加上颜色，换用不同的字体（默认是宋体，换体就要加代码），只要在文字前加上<FONT face=楷体_GB2312 color=#ff0000 size=3>就行了，你可在“face=”后边换上你喜欢的字体，在“color=”后边换上你喜欢的字颜色，在“size=”后边换上适合的字号，如果想让字体加粗，就再加上<STRONG>。
        `
    },
    {
        id:4,
        title:'关于动态生成的mp3在audio标签无法拖动的问题',
        author:'米一天',
        tag:'CSS',
        desc:'最近，在项目中尝试使用html5中的audio标签做web版的播放器，因为涉及到付费的音频，所以需要对用户权限做一些判断，然后动态输出mp3。但是，动态生成的mp3在chrome中无法正常拖动。',
        readcount:4831,
        createTime:new Date('2022/2/10 21:23:40'),
        content:
        `
        最近，在项目中尝试使用html5中的audio标签做web版的播放器，因为涉及到付费的音频，所以需要对用户权限做一些判断，然后动态输出mp3。但是，动态生成的mp3在chrome中无法正常拖动。

        我们来看一下代码：
        
        <!doctype html> <html lang="en"> <head> <meta charset="UTF-8"> <title>Test</title> </head> <body> <audio src="http://localhost/demo/mp3.php" controls="controls"></audio> </body> </html> 
        header("Content-type:audio/mpeg");
        header('Content-Length: ' . filesize("1.mp3")); echo file_get_contents("1.mp3");
        进度条不能拖动
        
        
        
        将audio中的src修改成mp3源文件路径：
        
        <!doctype html> <html lang="en"> <head> <meta charset="UTF-8"> <title>Test</title> </head> <body> <audio src="http://localhost/demo/1.mp3" controls="controls"></audio> </body> </html> 
        在chrome中拖动正常
        
        
        
        猜想，莫非audio播放mp3后缀的音频文件才能拖动进度条？
        
        尝试配置apache解析后缀为mp3的php文件，将mp3.php改成mp3.mp3，问题依然存在。
        
        取消掉apache解析后缀为mp3文件的行为，将audio标签中的src修改为mp3源文件路径，利用chrome控制台查看audio标签如何请求以及响应。
        
        1.mp3的请求信息：
        
        
        
        请求头里面主要包含Range字段。 响应信息如下：
        
        响应的状态码：
        
        响应头信息：
        
        
        
        主要包含Accept-Ranges、Content-Range字段。 很明显，chrome请求mp3文件时采用的是断点续传。 当点击进度条时，相应的请求信息及响应信息如下：
        
        
        
        当点击进度条时，chrome浏览器会发起一条http请求，依然采用断点续传。
        
        根据以上分析，若要使动态生成的mp3能拖动进度，就必须在php文件中实现断点续传，在php中构造相应的响应头即可。
        
        最终，mp3.php代码如下：
        
        <?php $file = "1.mp3";
        $fileSize = filesize($file);
        $etag = md5(filemtime($file));
        $fp = fopen($file, 'rb'); if (!$fp) { die('Could not open file');
        }
        $start = 0;
        $end = $fileSize - 1; if (isset($_SERVER['HTTP_RANGE']) && !empty($_SERVER['HTTP_RANGE'])) { //获取请求头中的Range字段 $range = explode('-', substr($_SERVER['HTTP_RANGE'], strlen('bytes=')));
        
            $start = $range[0]; if ($range[1] > 0) {
                $end = $range[1];
            } //构造断点续传响应头 header('HTTP/1.1 206 Partial Content');
            header('Status: 206');
            header('Accept-Ranges: bytes');
            header('Content-Range: bytes ' . $start. '-' . $end . '/' . $fileSize);
            header('Content-Length: ' . ($end - $start + 1));
        } else {
            header('Content-Length: ' . $fileSize);
        }
        
        header('Content-Type: audio/mpeg');
        header('Last-Modified: ' . date('D, d M Y H:i:s \G\M\T', filemtime($file)));
        header('ETag: "' . $etag . '"');
        header('Expires: 0'); if ($start > 0) {
            fseek($fp, $start); //移动文件指针 }
        
        $bytesPosition = $start; while (!feof($fp) && $bytesPosition <= $end) {
        
            $chunk = 1024 * 1024 * 50; //每次读取50k if ($bytesPosition + $chunk > $end + 1) {
                $chunk = $end - $bytesPosition + 1;
            }
        
            $chunk = fread($fp, $chunk); if (!$chunk) { die('Could not read file');
            } print($chunk);
            flush();
        
            $bytesPosition += $chunk;
        }
        
        fclose($fp);
        至此，在audio标签中便可以使用php动态生成的mp3。
        `
    },
    {
        id:5,
        title:'JournalNode的作用',
        author:'selfish',
        tag:'Hadoop ',
        desc:'两个NameNode为了数据同步，会通过一组称作JournalNodes的独立进程进行相互通信。当active状态的NameNode的命名空间有任何修改时，会告知大部分的JournalNodes进程。standby状态的NameNode有能力读取JNs中的变更信息，并且一直监控edit log的变化，把变化应用于自己的命名空间。standby可以确保在集群出错时，命名空间状态已经完全同步了。',
        readcount:3299,
        createTime:new Date('2022/5/20 21:43:40'),
        content:
        `
            JournalNode的作用


            NameNode之间共享数据（NFS 、Quorum Journal Node（用得多））
            两个NameNode为了数据同步，会通过一组称作JournalNodes的独立进程进行相互通信。当active状态的NameNode的命名空间有任何修改时，会告知大部分的JournalNodes进程。standby状态的NameNode有能力读取JNs中的变更信息，并且一直监控edit log的变化，把变化应用于自己的命名空间。standby可以确保在集群出错时，命名空间状态已经完全同步了。
            Hadoop中的NameNode好比是人的心脏，非常重要，绝对不可以停止工作
            hadoop2.2.0（HA）中HDFS的高可靠指的是可以同时启动2个NameNode。其中一个处于工作状态，另一个处于随时待命状态。这样，当一个NameNode所在的服务器宕机时，可以在数据不丢失的情况下，手工或者自动切换到另一个NameNode提供服务。
            这些NameNode之间通过共享数据，保证数据的状态一致。多个NameNode之间共享数据，可以通过Nnetwork File System或者Quorum Journal Node。前者是通过linux共享的文件系统，属于操作系统的配置；后者是hadoop自身的东西，属于软件的配置。
            我们这里讲述使用Quorum Journal Node的配置方式，方式是手工切换。
            集群启动时，可以同时启动2个NameNode。这些NameNode只有一个是active的，另一个属于standby状态。active状态意味着提供服务，standby状态意味着处于休眠状态，只进行数据同步，时刻准备着提供服务，如图2所示。
            
            参考资料：
            https://www.cnblogs.com/muhongxin/p/9436765.html
        `
    },
    {
        id:7,
        title:'Hadoop分布式集群的构建',
        author:'snop',
        tag:'Hadoop ',
        desc:'Hadoop作为通用的大数据处理平台，利用HDFS存储海量数据，利用YARN统一管理资源调度，所以搭建Hadoop集群其实就是分别搭建HDFS分布式集群和YARN分布式集群。',
        readcount:2385,
        createTime:new Date('2022/8/06 11:25:20'),
        content:
        `
        Hadoop分布式集群的构建

        Hadoop分布式集群的构建
        Hadoop作为通用的大数据处理平台，利用HDFS存储海量数据，利用
        YARN统一管理资源调度，所以搭建Hadoop集群其实就是分别搭建HDFS分
        布式集群和YARN分布式集群。搭建分布式集群环境对于初学者有一定的
        难度，本章将详细讲解Hadoop分布式集群的安装部署。
        
        3.4.1 HDFS分布式集群的构建
        搭建Hadoop集群，首先需要安装配置HDFS集群，具体操作步骤如
        下。
        1.下载解压Hadoop
        首先在Hadoop官网（地址为
        https://archive.apache.org/dist/hadoop/common/）下载Hadoop稳定
        版本的安装包hadoop-2.9.1.tar.gz（也可通过本书配套资料包下载获
        取：本书配套资料/第3章/3.4/安装包），然后上传至hadoop01节点下
        的/home/hadoop/app目录下，具体操作如下所示
        要修改的HDFS配置文件包括：hadoop-env.sh、core-site.xml、
        hdfs-site.xml、slaves四个。相应文件可通过本书配套资资源包获取
        （本书配套资料/第3章/3.4/配置文件）。
        （1）修改hadoop-env.sh配置文件
        hadoop-env.sh文件主要配置与Hadoop环境相关的变量，这里主要
        修改JAVA_HOME的安装目录，
        （2）修改core-site.xml配置文件
        core-site.xml文件主要配置Hadoop的公有属性
        （3）修改hdfs-site.xml配置文件
        hdfs-site.xml文件主要配置和HDFS相关的属性
        （4）配置slaves文件
        slaves文件主要根据集群规划配置DataNode节点所在的主机名
        3.启动HDFS集群
        （1）启动Zookeeper集群
        在集群所有节点分别启动Zookeeper服务
        （2）启动JournalNode集群
        在集群所有节点分别启动JournalNode服务，
        （3）格式化主节点NameNode
        在hadoop01节点（NameNode主节点）上，使用如下命令对NameNode
        进行格式化。
        （4）备用NameNode同步主节点的元数据
        在hadoop01节点启动NameNode服务的同时，需要在hadoop02节点
        （NameNode备用节点）上执行如下命令同步主节点的元数据。
        （5）关闭JournalNode集群
        hadoop02节点同步完主节点元数据后，紧接着在hadoop01节点上，
        按下〈Ctrl+C〉组合键来结束NameNode进程，然后关闭所有节点上的
        JournalNode进程，具体操作如下所示。
        （6）一键启动HDFS集群
        如果上面操作没有问题，在hadoop01节点上，可以使用脚本一键启
        动HDFS集群所有相关进程
        注意：第一次安装HDFS需要对NameNode进行格式化，HDFS集群安装
        成功之后，使用一键启动脚本start-dfs.sh即可启动HDFS集群所有进
        程。
        4.验证HDFS是否启动成功
        在浏览器中输入网址http://hadoop01:50070，通过Web界面查看
        hadoop01节点NameNode的状态，结果如图3-23所示。该节点的状态为
        active，表示HDFS可以通过hadoop01节点的NameNode对外提供服务。
        在浏览器中输入网址http://hadoop02:50070，通过Web界面查看
        hadoop02节点的NameNode的状态，结果如图3-24所示。该节点的状态为
        standby，表示hadoop02节点的NameNode不能对外提供服务，只能作为
        备用节点。
        注意：哪个节点的NameNode处于active状态，由Zookeeper选举所
        得，且某一时刻只能有一个NameNode节点处于active状态。
        在hadoop01节点的/home/hadoop/app/hadoop目录下创建djt.txt文
        件（本书配套资料/第3章/3.4/数据集），然后上传至HDFS文件系统
        的/test目录下，检查HDFS是否能正常使用，具体操作如下。
        如果上面操作没有异常，说明HDFS集群安装配置成功。
        
        3.4.2 YARN分布式集群的构建
        HDFS集群安装成功之后，接下来安装配置YARN集群，具体操作步骤
        如下。
        1.修改mapred-site.xml配置文件
        mapred-site.xml文件（本书配套资料/第3章/3.4/配置文件）主
        要配置和MapReduce相关的属性，具体需要配置的每个属性的注释如
        下。这里主要配置MapReduce的运行框架名称为YARN
        2.修改yarn-site.xml配置文件
        yarn-site.xml文件（本书配套资料/第3章/3.4/配置文件）主要
        配置和YARN相关的属性，具体需要配置的每个属性的注释如下。
        3.向所有节点同步YARN配置文件
        在hadoop01节点上修改完YARN相关的配置之后，将修改的配置文件
        远程复制到hadoop02节点和hadoop03节点，具体操作如下所示。
        4.启动YARN集群
        （1）启动YARN集群
        在hadoop01节点上，使用脚本一键启动YARN集群，
        注意：在启动YARN集群之前，首先需要启动Zookeeper集群。
        （2）启动备用ResourceManager
        因为start-yarn.sh脚本不包含启动备用的ResourceManager进程，
        所以需要在hadoop02节点上单独启动ResourceManager
        （3）Web界面查看YARN集群
        在浏览器中输入网址http://hadoop01:8088（或
        http://hadoop02:8088），通过Web界面查看YARN集群信息
        （4）检查ResourceManager状态
        在hadoop01节点上，使用命令查看两个ResourceManager状态
        如果一个ResourceManager为active状态，另外一个
        ResourceManager为standby状态，说明YARN集群构建成功。
        `
    },
    {
        id:8,
        title:'正则表达式的匹配过程',
        author:'yofe',
        tag:'Linux',
        desc:'每一轮正则的匹配，都需要从正则的第一个元素从头开始匹配。',
        readcount:3414,
        createTime:new Date('2021/7/10 23:43:40'),
        content:
        `
        reg:abc

        str:"aabxabcxyz"
        
        每一轮正则的匹配，都需要从正则的第一个元素从头开始匹配。
        
        第一轮匹配：
        
            扫描第一个字符，和正则表达式的第一个元素进行匹配
        
            如果匹配失败，则意味着这一轮的正则匹配失败
        
        第二轮匹配：
        
            扫描下一个字符，从头开始和正则表达式进行匹配
        
            如果匹配成功，则继续扫描下一个字符和正则表达式的下一个元素进行匹配
        
        l  如果这个字符匹配失败，则导致这一轮正则匹配失败
        
        l  交还除第二轮匹配开始的首字符外的所有字符
        
        l  交还之后，从交还的第一个字符开始进入下一轮匹配
        
        第三轮匹配：
        
            如果这一轮正则匹配成功，则不交还匹配成功的字符
        
            然后从匹配成功的下一个字符进入下一轮匹配
        
        字符消耗问题：
        
            某轮正则匹配成功，则消耗所有匹配成功的字符
        
            某轮匹配失败，则消耗本轮匹配的首字符，剩余的字符被交还
        
        案例：
        
        解读以上案例
        
        reg:abc
        
        str:"aabxabcxyz"
        
        正则表达式有3个元素abc
        
        第一轮：
        
        字符串第一个字符a和正则表达式第一个元素a匹配，匹配成功，则字符串的第二个字符a和正则表达式的第二个元素b匹配，匹配失败，本轮结束，本轮消耗掉字符串中的第一个字符a
        
        第二轮：
        
        一轮消耗掉了字符串中的第一个字符a，本轮从字符串第二个字符a开始，a和正则表达式第一个元素a匹配，匹配成功，接下来b和正则表达式的第二个元素b匹配，匹配成功，x和正则表达式的第三个元素c匹配，匹配失败，本轮结束，本轮消耗掉字符串中的第二个a
        
        第三轮：
        
               二轮消耗掉了字符串中的第二个字符a，本次从字符串的第三个字符b开始，b和正则表达式的第一个元素a匹配，匹配失败，继续扫描下一个字符
        
        第四轮：
        
               x和正则表达式第一个元素a匹配，匹配失败，继续扫描下一个字符
        
        第五轮：
        
        字符串第五个字符a和正则表达式第一个元素a匹配，匹配成功，接下来b和正则表达式的第二个元素b匹配，匹配成功，c和正则表达式的第三个元素c匹配，匹配成功，本轮结束，本轮消耗掉字符串中的第五、六、七个字符
        
        第六轮：
        
               字符串第八个字符x和正则表达式第一个元素a匹配，匹配失败，继续扫描下一个字符
        
        第七轮：
        
               字符串第九个字符y和正则表达式第一个元素a匹配，匹配失败，继续扫描下一个字符
        
        第八轮：
        
               字符串第十个字符z和正则表达式第一个元素a匹配，匹配失败，继续扫描下一个字符
        
        匹配结束，匹配的结果是abc
        `
    }
] 

export const top = [
    {
        id:9,
        title:'js获取IP地址的4种方法',
        author:'doc-Q',
        tag:'JavaScript',
        desc:'js取得ip地址的方法三，腾讯IP，转UTF-8',
        readcount:225,
        createTime:new Date('2023/1/15 22:23:40'),
        content:
        `
            1，js取得IP地址的方法一


            2，js取得IP地址的方法二
            
            
            
            3，js取得ip地址的方法三，腾讯IP，转UTF-8：
            
            
            $(document).ready(function() {
            
            $("#ip").val(IPData[0]);
            $("#add").val(IPData[2]);
            })
            4.
            
            website:click me
            
        
        `
    },
    {
        id:10,
        title:'Synchronous XMLHttpRequest on the main thread is deprecated',
        author:'ttzze',
        tag:'JavaScript',
        desc:'原因是你的ajax执行了同步操作',
        readcount:244,
        createTime:new Date('2023/1/14 21:23:40'),
        content:
        `
            Synchronous XMLHttpRequest on the main thread is deprecated
            原因是你的ajax执行了同步操作，即async设置为False，当然它并不影响程序的运行，但是右边有一道黄杠确实令人不爽，建议还是改成True为好(不设置默认为True)。
        
        `
    },
    {
        id:11,
        title:'Java gson格式化输出json字符串',
        author:'ttzze',
        tag:'Java ',
        desc:'import com.google.gson.*;',
        readcount:123,
        createTime:new Date('2023/1/11 14:23:40'),
        content:
        `
        Java gson格式化输出json字符串


        import com.google.gson.*;
        
        /**
         * 格式化json字符串
         * @author tzq
         * @time 2022/07/14
         */
        public class GsonTest {
        
            public static void main(String[] args) {
                String compactJson = "{\"playerID\":1234,\"name\":\"Test\",\"itemList\":[{\"itemID\":1,\"name\":\"Axe\",\"atk\":12,\"def\":0},{\"itemID\":2,\"name\":\"Sword\",\"atk\":5,\"def\":5},{\"itemID\":3,\"name\":\"Shield\",\"atk\":0,\"def\":10}]}";
                String prettyJson = toPrettyFormat(compactJson);
                System.out.println("compactJson:");
                System.out.println(compactJson);
                System.out.println("prettyJson:");
                System.out.println(prettyJson);
            }
        
            public static String toPrettyFormat(String json) {
                JsonParser jsonParser = new JsonParser();
                JsonObject jsonObject = jsonParser.parse(json).getAsJsonObject();
                Gson gson = new GsonBuilder().setPrettyPrinting().create();
                return gson.toJson(jsonObject);
            }
        }
        
        `
    },
    {
        id:12,
        title:'openGauss数据库之Python驱动快速入门',
        author:'ttzze',
        tag:'openGauss',
        desc:'openGauss数据库之Python驱动快速入门',
        readcount:94,
        createTime:new Date('2023/1/10 21:23:40'),
        content:
        `
            openGauss数据库之Python驱动快速入门
            https://blog.csdn.net/GaussDB/article/details/121330008
        
        `
    },
    {
        id:13,
        title:'Python使用jdbc对openGauss数据库进行操作(一)',
        author:'ttzze',
        tag:'openGauss',
        desc:' Python使用jdbc对openGauss数据库进行操作(一)',
        readcount:34,
        createTime:new Date('2023/1/9 21:23:40'),
        content:
        `
            Python使用jdbc对openGauss数据库进行操作(一)
            https://www.cnblogs.com/peterlddlym/p/14724112.html
        
        `
    },
    {
        id:14,
        title:'redis缓存穿透击穿雪崩区别和解决方案',
        author:'ttzze',
        tag:'Redis',
        desc:'redis缓存穿透击穿雪崩区别和解决方案',
        readcount:47,
        createTime:new Date('2023/1/8 21:23:40'),
        content:
        `
            https://blog.csdn.net/fcvtb/article/details/89478554
        
        `
    },
    {
        id:15,
        title:'Redis持久化之RDB和AOF',
        author:'ttzze',
        tag:'Redis',
        desc:'Redis持久化之RDB和AOF',
        readcount:544,
        createTime:new Date('2023/1/7 21:23:40'),
        content:
        `
            https://www.cnblogs.com/itdragon/p/7906481.html
        
        `
    },
    {
        id:16,
        title:'ping得到主机名',
        author:'ttzze',
        tag:'Windows',
        desc:'ping得到主机名',
        readcount:122,
        createTime:new Date('2023/1/6 21:23:40'),
        content:
        `
            ping得到主机名 ping -a ip
        
        `
    },
    {
        id:17,
        title:'详解什么是 Oracle RAC 脑裂',
        author:'doc-Q',
        tag:'Windows',
        desc:'ping得到主机名',
        readcount:226,
        createTime:new Date('2023/1/6 21:23:40'),
        content:
        `
            详解什么是 Oracle RAC 脑裂
            http://www.kokojia.com/article/58932.html
        
        `
    }
]

export const mypublish = [
    {
        id:18,
        title:'js获取IP地址的4种方法',
        author:'doc-Q',
        tag:'JavaScript',
        desc:'js取得ip地址的方法三，腾讯IP，转UTF-8',
        readcount:225,
        createTime:new Date('2023/1/15 22:23:40'),
        content:
        `
            1，js取得IP地址的方法一


            2，js取得IP地址的方法二
            
            
            3，js取得ip地址的方法三，腾讯IP，转UTF-8：
            
            
            $(document).ready(function() {
            
            $("#ip").val(IPData[0]);
            $("#add").val(IPData[2]);
            })
            4.
            
            website:click me
            
        
        `
    },
    {
        id:19,
        title:'详解什么是 Oracle RAC 脑裂',
        author:'doc-Q',
        tag:'Windows',
        desc:'ping得到主机名',
        readcount:226,
        createTime:new Date('2023/1/6 21:23:40'),
        content:
        `
            详解什么是 Oracle RAC 脑裂
            http://www.kokojia.com/article/58932.html
        
        `
    }
]

//草稿箱
export const drafts = [
    {
        id:20,
        title:'JS filter()方法 介绍和使用',
        author:'doc-Q',
        tag:'JavaScript',
        desc:'filter方法是js中常用的方法',
        readcount:0,
        createTime:new Date('2023/1/8 12:23:40'),
        content:
        `
            filter方法是js中常用的方法；
            一，作用；
            filter用于对数组进行过滤。
            它创建一个新数组，新数组中的元素是通过检查指定数组中符合条件的所有元素。
            二，语法；Array.filter(function(currentValue, indedx, arr), thisValue)
            其中，函数 function 为必须，数组中的每个元素都会执行这个函数。且如果返回值为 true，则该元素被保留；
            函数的第一个参数 currentValue 也为必须，代表当前元素的值。
            三，实例；
            举个栗子：
            返回数组nums中所有大于5的元素；
        `
    }
]