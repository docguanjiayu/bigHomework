<template>
    <div class="about">
        <div class="main">
            <div class="title">Web大作业报告</div>
            <div class="body">
                <span>一、用到的主要技术、工具：</span>
                <p>vue3、element-ui plus组件库、pinia状态管理插件、vue-router路由插件、axios插件、moment时间格式处理工具、less css预处理语言、json-server工具。</p>
                <br>
                <span>二、开发过程中遇到的问题：</span>
                <p>写文章，自动保存的设计，想法是使用定时器，隔一段设置的时间就调用保存的函数，以达到自动保存的目的，但是没有弄出来。后来又想到使用watch监听文章正文部分用户输入的变化，但是会频繁保存，性能太差，之后也没有想到什么特别好的实现方式，就暂时放弃了。</p>
                <br>
                <span>三、网站介绍：</span>
                <p>网站名字为前端博客网</p>
                <br>
                <span>四、网站主题：</span>
                <p>简约的个人博客</p>
                <br>
                <span>五、页面组织结构：</span>
                <p>先是登录与注册页面，然后是主页面，主页面中包含三个子页面，第一个是首页用于展示最近发表的博文和热门博文，第二个是发表页，主要功能在发表页中，第三个撰写的报告。</p>
                <br>
                <div class="image">
                    <img src="../../assets/images/002.gif" alt="">
                </div>
                <span>六、网站内容：</span>
                <div class="image">
                    <img src="../../assets/images/003.gif" alt="">
                </div>
                <p>1、登录和注册通过jsonsever将数据存储到了数据库中，注册后可以在链接中看到相应的账号密码。</p>
                <p>2、登入后会进入到个人中心 里面有自己发布的博文，可以进行查看（只可读模式）和删除</p>
                <div class="image">
                    <img src="../../assets/images/004.jpg" alt="">
                </div>
                <p>3、还有草稿箱 可以将自己还没写完的博文缓存在这里，可以进行查看、删除、编辑的功能 </p>
                <div class="image">
                    <img src="../../assets/images/005.jpg" alt="">
                </div>
                <p>4、还有用户设置，可以更改自己的昵称、手机号、性别和密码。</p>
                <div class="image">
                    <img src="../../assets/images/006.jpg" alt="">
                </div>
                <p>5、如果需要发表博文可以点击发表页面，填写好相应的内容后即可发表，完成作业三的基本功能。</p>
                <div class="image">
                    <img src="../../assets/images/007.jpg" alt="">
                </div>
                <p>6、最后是首页页面，在首页中可以看到热门的博文，还有最近发表的博文，点击博文可以看到相应内容，也可以评论和点赞 </p>
                <div class="image">
                    <img src="../../assets/images/008.jpg" alt="">
                </div>
                <div class="image">
                    <img src="../../assets/images/009.jpg" alt="">
                </div>
            </div>
        </div>
    </div>
</template>

<style scoped lang='less'>
.about{
    width: 100%;
    background-color: #fff;
    margin-top:20px;
    font-size:16px;
    padding:20px 0;
    .main{
        width:960px;
        margin:auto;

        .title{
            text-align: center;
            padding:20px 0;
            font-size: 20px;
            margin-bottom: 20px;
        }

        .body{
            span{
                color:#444;
                font-weight: bold;
            }
            p{
                margin-top: 10px;
                text-indent: 32px;
            }
            .image{
                width: 100%;
                padding:20px 0;
                img{
                    width: 100%;
                    height: auto;
                }
            }
        }
    }
}
</style>